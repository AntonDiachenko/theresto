module.exports = (sequelize, Datatypes) => {
    const Favorites = sequelize.define("Favorites", {
    

    });
  

    return Favorites;
  };
  