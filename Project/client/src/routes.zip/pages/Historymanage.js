import React from 'react'

function Historymanage() {
  return (
    <div>
      History
    </div>
  )
}

export default Historymanage
